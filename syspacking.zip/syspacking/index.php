<?php

require_once "controller/ControllerTemplate.php";

$render = new TemplateController();
$render -> ctrRender();