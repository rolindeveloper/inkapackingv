<div class="w3-container w3-padding">

    <h3 class="w3-font-bold w3-font-large">registrar <span class="w3-text-green">calibrado</span></h3>

    <hr>

    <div class="w3-container">

        <div class="w3-row-padding w3-container">

            <div class="w3-col l4">

                <p>
                    <select name="selLote" class="w3-select" id="selLote">

                        <option value="0001">0001</option>

                        <option value="0001">0001</option>

                        <option value="0001">0001</option>

                    </select>

                </p>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

                <div class="w3-col l6 w3-container">
                    <p class="w3-text-grey w3-font-large">
                        Producto
                    </p>
                    <input type="text" class="w3-input w3-light-grey">
                </div>

            </div>

            <div class="w3-col l4 w3-padding">

                <p class="w3-text-grey w3-font-large">

                    Detalle calibrado
                </p>

                <hr>

                <p class="w3-text-grey w3-font-large">Selecciona</p>

                <select name="selDestino" class="w3-select w3-border" id="selDestino">
                    <option value="USA">USA</option>
                    <option value="EUROPA">EUROPA</option>
                    <option value="JAPÓN">JAPÓN</option>
                    <option value="CHINA">CHINA</option>
                    <option value="CHILE">CHILE</option>
                    <option value="MÉXICO">MÉXICO</option>
                    <option value="NUEVA ZELANDA">NUEVA ZELANDA</option>
                </select>

                <div class="w3-section">

                    <hr>

                    <p class="w3-text-grey w3-font-large">
                        Detalle calibrado
                    </p>

                    <?php

                        for ($i=1; $i < 8 ; $i++) { 
                            
                            echo '<div class="w3-row-padding">

                        <div class="w3-col l4 w3-container">

                            <label for="">Calibre</label>

                            <select name="calibre" class="w3-select" id="calibre">

                                <option value="C4">C4</option>
                                <option value="C4">C4</option>
                                <option value="C4">C4</option>
                                <option value="C4">C4</option>
                                <option value="C4">C4</option>
                                <option value="C4">C4</option>
                                <option value="C4">C4</option>

                            </select>
                            
                        </div>

                        <div class="w3-col l4 w3-container">
                            <label for="jabas">Jabas</label>
                            <input type="text" class="w3-input">
                        </div>

                        <div class="w3-col l4 w3-container">
                            <br>
                            <input type="text" class="w3-input w3-light-grey" readonly>
                        </div>
                    </div>';
                        }

                    ?>

                </div>

            </div>

        </div>

        <hr>
 
        <div class="w3-row-padding">

            <div class="w3-container">

                <p class="w3-text-grey w3-font-large w3-container">Información Calibrado: </p>

                <div class="w3-col l3 w3-container">

                    <p>
                        <label for="FechaCalibracion" class="w3-text-grey w3-font-large">Fecha Calibración</label>
                    </p>

                    <input type="text" class="w3-input w3-border">

                </div>

                <div class="w3-col l3 w3-container">
                    <p>
                        <label for="FechaCalibracion" class="w3-text-grey w3-font-large">Semana</label>
                    </p>
                    <input type="text" class="w3-input w3-border">
                </div>

                <div class="w3-col l3 w3-container">
                    <p>
                        <label for="FechaCalibracion" class="w3-text-grey w3-font-large">Días Almacenamiento</label>
                    </p>
                    <input type="text" class="w3-input w3-border">
                </div>

                <div class="w3-col l3 w3-container">
                    <p>
                        <label for="FechaCalibracion" class="w3-text-grey w3-font-large">Total Jabas</label>
                    </p>
                    <input type="text" class="w3-input w3-border">
                </div>
            </div>
        </div>

        <div class="w3-row-padding">

            <div class="w3-container">

                <div class="w3-col l3 w3-container">

                    <p>
                        <label for="FechaCalibracion" class="w3-text-grey w3-font-large">Kg. Netos</label>
                    </p>

                    <input type="text" class="w3-input w3-border">

                </div>

                <div class="w3-col l3 w3-container">
                    <p>
                        <label for="FechaCalibracion" class="w3-text-grey w3-font-large">Prom. Jaba Neto</label>
                    </p>
                    <input type="text" class="w3-input w3-border">
                </div>

                <div class="w3-col l3 w3-container">
                    <p>
                        <label for="FechaCalibracion" class="w3-text-grey w3-font-large">Jabas descarte</label>
                    </p>
                    <input type="text" class="w3-input w3-border">
                </div>

                <div class="w3-col l3 w3-container">
                    <p>
                        <label for="FechaCalibracion" class="w3-text-grey w3-font-large">Kg. descarte</label>
                    </p>
                    <input type="text" class="w3-input w3-border">
                </div>
            </div>
        </div>

        <div class="w3-row-padding">

            <div class="w3-container">

                <div class="w3-col l3 w3-container">

                    <p>
                        <label for="FechaCalibracion" class="w3-text-grey w3-font-large">Prom. Jaba descarte</label>
                    </p>

                    <input type="text" class="w3-input w3-border">

                </div>

                <div class="w3-col l3 w3-container">
                    <p>
                        <label for="FechaCalibracion" class="w3-text-grey w3-font-large">% Descarte</label>
                    </p>
                    <input type="text" class="w3-input w3-border">
                </div>

                <div class="w3-col l3 w3-container">
                    <p>
                        <label for="FechaCalibracion" class="w3-text-grey w3-font-large">Estado</label>
                    </p>
                    <select name="selEstado" class="w3-select w3-border" id="selEstado">
                        <option value="Calibrado">Calibrado</option>
                    </select>
                </div>

                <div class="w3-col l3 w3-container">
                    <p><br></p>
                    <button class="w3-btn w3-round w3-tiny w3-green">Obtener Datos</button>
                    <button class="w3-btn w3-round w3-tiny w3-green">Calcular Descarte</button>
                </div>
            </div>
        </div>

        <hr>

        <div class="w3-row-padding">
            <button class="w3-right w3-btn w3-round w3-theme-d5">Registrar calibrado</button>
        </div>

    </div>

</div>

<script src="view/js/nueva-recepcion.js"></script>