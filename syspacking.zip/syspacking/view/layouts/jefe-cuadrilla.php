<div class="w3-container w3-padding">

    <h3 class="w3-font-bold w3-font-large">Gestor <span class="w3-text-green">jefe cuadrilla</span></h3>

    <hr>

    <div class="w3-container">

        <button type="button" class="w3-btn w3-round w3-small w3-green"> Nuevo <i class="fa fa-user-circle"></i> </button>

    </div>

    <div class="w3-container w3-section">

        <table class="w3-table-all w3-padding">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nombres</th>
                    <th>N° Celular</th>
                    <th>Dirección</th>
                    <th>Correo</th>
                    <th>Tipo Documento</th>
                    <th>N° Documento</th>
                </tr>
            </thead>
        </table>

    </div>

</div>