<div class="w3-container w3-padding">

    <h3 class="w3-font-bold w3-font-large">nuevo <span class="w3-text-green">registro empaque</span></h3>

    <hr>

    <div class="w3-container">

    </div>

</div>
