<div class="w3-container w3-padding">

    <h3 class="w3-font-bold w3-font-large">Gestor <span class="w3-text-green">usuarios</span></h3>

    <hr>

    <div class="w3-container">

        <button type="button" onclick="document.getElementById('modalVariedad').style.display='block'" class="w3-btn w3-round w3-small w3-green"> Nuevo <i class="fa fa-user-circle"></i> </button>

    </div>

    <div class="w3-container w3-section">

        <table class="w3-table-all w3-padding">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nombres</th>
                    <th>N° Celular</th>
                    <th>Dirección</th>
                    <th>Correo</th>
                    <th>Tipo Documento</th>
                    <th>N° Documento</th>
                </tr>
            </thead>
        </table>

    </div>

</div>

<div id="modalVariedad" class="w3-modal">

  <div class="w3-modal-content w3-animate-opacity" style="width: 700px;">

    <header class="w3-container w3-theme-d5">

      <span onclick="document.getElementById('modalVariedad').style.display='none'"
        class="w3-button w3-display-topright">&times;</span>

      <h5 class="w3-font-large">registrar usuario</h5>
    </header>

    <form method="post" id="formulario" enctype="multipart/form-data">
      
      <div class="w3-row-padding">
        
        <div class="w3-col l6 w3-container">
            <p class="w3-font-large w3-text-grey">Nombres</p>
            <input type="text" id="nombres" class="w3-input w3-border">
        </div>

        <div class="w3-col l6 w3-container">
            <p class="w3-font-large w3-text-grey">Apellidos</p>
            <input type="text" id="apellidos" class="w3-input w3-border">
        </div>

        <div class="w3-col l6 w3-container">
            <p class="w3-font-large w3-text-grey">Correo</p>
            <input type="email" id="email" class="w3-input w3-border">
        </div>

        <div class="w3-col l6 w3-container">
            <p class="w3-font-large w3-text-grey">Dirección</p>
            <input type="text" id="direccion" class="w3-input w3-border">
        </div>

        <div class="w3-col l4 w3-container">
            <p class="w3-font-large w3-text-grey">Tipo Documento</p>
            <select name="selTipoDocumento" id="selTipoDocumento" class="w3-select w3-border">
                <option value="DNI">DNI</option>
                <option value="RUC">RUC</option>
            </select>
        </div>

        <div class="w3-col l4 w3-container">
            <p class="w3-font-large w3-text-grey">N° Documento</p>
            <input type="number" class="w3-input w3-border" name="nDocumento" id="nDocumento">
        </div>

        <div class="w3-col l4 w3-container">
            <p class="w3-font-large w3-text-grey">Teléfono</p>
            <input type="tel" class="w3-input w3-border" name="tlf" id="telefono">
        </div>

      </div>

      <div class="w3-row-padding">

        <div class="w3-col l6 w3-container">
            <p class="w3-font-large w3-text-grey">Password</p>
            <input type="password" class="w3-input w3-border" name="pass" id="password" autocomplete="off">
        </div>

        <div class="w3-col l6 w3-container">
            <p class="w3-font-large w3-text-grey">Foto</p>
            <input type="file" class="w3-input w3-border" name="photoProfile" id="photoProfile">
        </div>


      </div>

      <footer class="w3-container">
        <hr>
        <p>
          <button type="button" class="w3-btn w3-round w3-small w3-red" onclick="document.getElementById('modalVariedad').style.display='none'">
            Cerrar
          </button>

          <button type="submit" class="w3-btn w3-round w3-small w3-green w3-right btnGuardar">
            Guardar <i class="fa fa-save"></i>
          </button>
        </p>
      </footer>
    </form>

  </div>

</div>

<script src="view/js/usuarios.js"></script>