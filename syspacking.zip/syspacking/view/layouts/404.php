<div class="w3-container w3-padding">
    <div class="w3-content">
        <h3 class="w3-font-bold w3-font-large w3-center">Error <span class="w3-text-green">404</span></h3>
        <hr>

        <div class="w3-container w3-center">
            <p class="w3-text-grey w3-font-large">
                La página solicitada no pudo ser procesada, regresa al menú haciendo click <a class="w3-text-red" href="inicio" style="text-decoration: none;">aquí</a>.
            </p>
        </div>
    </div>
</div>