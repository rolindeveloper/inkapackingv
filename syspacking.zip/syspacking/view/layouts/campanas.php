<div class="w3-container w3-padding">

    <h3 class="w3-font-bold w3-font-large">Listado <span class="w3-text-green">campañas</span></h3>

    <hr>

    <div class="w3-container">

        <div class="w3-section">
            <button class="w3-btn w3-round-xlarge w3-dark-grey" onclick="document.getElementById('modalAddCampana').style.display='block'"> <b><i class="fa fa-plus"></i></b> Registrar </button>
        </div>

        <table class="w3-table-all" id="listado-recepcion">
            <thead>
                <tr class="">
                    <th>Producto</th>
                    <th>Fecha Inicio</th>
                    <th>Fecha Fin</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Mango</td>
                    <td>2024-08-27</td>
                    <td></td>
                    <td><button class="w3-tiny w3-btn w3-green w3-round ">Activo</button></td>
                    <td>
                        <button class="w3-btn w3-tiny w3-round w3-red"><i class="fa fa-trash"></i></button>
                    </td>
                </tr>
            </tbody>
        </table>

    </div>

</div>

<div id="modalAddCampana" class="w3-modal">

  <div class="w3-modal-content w3-animate-opacity" style="width: 500px;">

    <header class="w3-container w3-theme-d5">

      <span onclick="document.getElementById('modalAddCampana').style.display='none'"
        class="w3-button w3-display-topright">&times;</span>

      <h5 class="w3-font-large">registrar variedad</h5>
    </header>

    <form method="post" id="formulario">
      
      <div class="w3-row-padding">
        <div class="w3-col">
        
            <p>
                <label for="nombreVariedad" class="w3-font-large w3-text-grey">Producto</label>
            </p>

            <select name="producto" id="producto" class="w3-select">
                <option selected disabled>Seleccione...</option>
                <option value="Mango">Mango</option>
                <option value="Palta">Palta</option>
            </select>

            <p>
                <label for="nombreVariedad" class="w3-font-large w3-text-grey">Fecha</label>
            </p>

            <input type="datetime-local" class="w3-input" required>

        </div>
      </div>

      <footer class="w3-container">
        <hr>
        <p>
          <button type="button" class="w3-btn w3-round w3-small w3-sand" onclick="document.getElementById('modalAddCampana').style.display='none'">
            Cerrar
          </button>

          <button type="submit" class="w3-btn w3-round w3-small w3-green w3-right btnSuspencion">
            Guardar <i class="fa fa-save"></i>
          </button>
        </p>
      </footer>
    </form>

  </div>

</div>


<script src="view/js/nueva-recepcion.js"></script>