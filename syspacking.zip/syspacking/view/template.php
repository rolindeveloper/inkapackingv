
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="view/css/w3.css">
    <link rel="stylesheet" href="view/css/w3-theme-indigo.css">
    <link rel="stylesheet" href="view/css/w3-colors-win8.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.14.0/build/alertify.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <!-- CSS -->
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.14.0/build/css/alertify.min.css"/>
    <!-- Default theme -->
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.14.0/build/css/themes/default.min.css"/>
    <!-- Semantic UI theme -->
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.14.0/build/css/themes/semantic.min.css"/>
    </head>

<body class="w3-small">

    <?php
        include "layouts/header.php";
        include "layouts/menu.php";

        if(isset($_GET["route"])) {

            if($_GET["route"] == "inicio" ||
               $_GET["route"] == "nueva-recepcion" ||
               $_GET["route"] == "lista-recepcion" ||
               $_GET["route"] == "campanas" ||
               $_GET["route"] == "nuevo-calibrado" ||
               $_GET["route"] == "lista-calibrado" ||
               $_GET["route"] == "descarte" ||
               $_GET["route"] == "nuevo-hidrotermico" ||
               $_GET["route"] == "datos-tratamiento" ||
               $_GET["route"] == "nuevo-registro-empaque" ||
               $_GET["route"] == "usuarios" ||
               $_GET["route"] == "jefe-cuadrilla") {

                include "layouts/".$_GET["route"].".php";

            } else {

                include "layouts/404.php";

            }

        } else {
            
            include "layouts/inicio.php";

        }

        
    ?>
    
   
</body>

</html>
