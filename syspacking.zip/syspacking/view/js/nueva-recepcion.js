
//variables
const selProducto = document.querySelector('#producto');
const numeroLote = document.querySelector('#numero-lote');
const startDate = document.querySelector('#startDate');
const endDate = document.querySelector('#endDate');

loadListers();

function loadListers() {

    startDate.addEventListener('change', readStart);

    endDate.addEventListener('change', readEnd)

}

function readStart(e) {
    e.preventDefault();
    console.log(e.target.value);
    
}

function readEnd(e) {
    e.preventDefault();
    console.log(e.target.value);
    
}