//variables
const formulario = document.querySelector('#formulario');
const btnGuardar = document.querySelector('.btnGuardar');

loadlisters();

//funciones
function loadlisters() {

    btnGuardar.addEventListener('click', readData);
    
}

//funciones globales
function readData(e) {

    e.preventDefault();
    
    const nombres = document.querySelector('#nombres').value;
    const apellidos = document.querySelector('#apellidos').value;
    const email = document.querySelector('#email').value;
    const direccion = document.querySelector('#direccion').value;
    const selTDoc = document.querySelector('#selTipoDocumento').value;
    const documento = document.querySelector('#nDocumento').value;
    const telefono = document.querySelector('#telefono').value;
    const password = document.querySelector('#password').value;
    const foto = document.getElementById('photoProfile').files[0];
    
    validateInformation(nombres, apellidos, email, direccion, selTDoc, documento, telefono, password, foto);   
    
}

function validateInformation(nombres, apellidos, email, direccion, selTDoc, documento, telefono, password, foto) {

    if([nombres, apellidos, email, direccion, selTDoc, documento, telefono, password, foto].includes('')) {

        alertify.error('CAMPOS INCOMPLETOS');
        return;

    }

    sendData(nombres, apellidos, email, direccion, selTDoc, documento, telefono, password, foto);
    

}

async function sendData(nombres, apellidos, email, direccion, selTDoc, documento, telefono, password, foto) {

    const datos = new FormData();
    datos.append('nombres', nombres);
    datos.append('apellidos', apellidos);
    datos.append('email', email);
    datos.append('direccion', direccion);
    datos.append('selTDoc', selTDoc);
    datos.append('documento', documento);
    datos.append('telefono', telefono);
    datos.append('password', password);
    datos.append('foto', foto);

}