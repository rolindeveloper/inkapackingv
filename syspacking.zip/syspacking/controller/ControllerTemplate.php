<?php

class TemplateController {

    public function ctrRender() {

        include "view/template.php";

    }

}